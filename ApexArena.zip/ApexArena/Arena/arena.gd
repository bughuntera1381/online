extends Node3D
## Builds the low-poly arena, lighting and environment entirely from code.
## Public variables/functions are kept compatible with the rest of the game.

const HALF := 30.0
const ARENA_COLOR := Color(0.24, 0.23, 0.20) # خاکستریِ خاک‌آلود آسفالت
const ARENA_DARK := Color(0.17, 0.17, 0.15)
const WALL_COLOR := Color(0.20, 0.19, 0.17)

var half: float = HALF
var spawn_points: Array[Vector3] = [
	Vector3(-25, 1.0, -25),
	Vector3(25, 1.0, 25),
	Vector3(-25, 1.0, 25),
	Vector3(25, 1.0, -25),
	Vector3(0, 1.0, -25),
	Vector3(0, 1.0, 25),
]

var waypoints: Array[Vector3] = [
	Vector3(-20, 0, -20), Vector3(20, 0, 20),
	Vector3(-20, 0, 20), Vector3(20, 0, -20),
	Vector3(0, 0, -10), Vector3(0, 0, 10),
	Vector3(-12, 0, 0), Vector3(12, 0, 0),
	Vector3(-12, 0, -16), Vector3(12, 0, 16),
	Vector3(-8, 0, -25), Vector3(8, 0, 25),
	Vector3(-26, 0, 10), Vector3(26, 0, -10),
]

# Kept for compatibility with any minimap/AI code using this array.
var map_rects: Array[Rect2] = []
var sun: DirectionalLight3D
var _mats: Dictionary = {}


func _ready() -> void:
	_build_environment()
	_build_ground()
	_build_walls()
	_build_cover()


# -------------------------------------------------------------------
# Materials
# -------------------------------------------------------------------

func _mat(color: Color) -> StandardMaterial3D:
	var key := color.to_html()
	if _mats.has(key):
		return _mats[key] as StandardMaterial3D

	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.9
	_mats[key] = material
	return material


@warning_ignore("unused_parameter")
func _emissive_mat(color: Color, energy: float = 2.5) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.emission_enabled = false
	material.emission = Color.BLACK
	material.emission_energy_multiplier = 0.0
	material.roughness = 0.65
	return material


# -------------------------------------------------------------------
# Environment and lighting
# -------------------------------------------------------------------

func _build_environment() -> void:
	var environment := Environment.new()
	environment.background_mode = Environment.BG_SKY

	var sky := Sky.new()
	var sky_material := ProceduralSkyMaterial.new()
	sky_material.sky_top_color = Color(0.16, 0.19, 0.20) # آسمان خاکستریِ پس از فاجعه
	sky_material.sky_horizon_color = Color(0.58, 0.43, 0.32)
	sky_material.ground_horizon_color = Color(0.34, 0.30, 0.25)
	sky_material.ground_bottom_color = Color(0.10, 0.11, 0.10)
	sky.sky_material = sky_material
	environment.sky = sky

	environment.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	environment.ambient_light_energy = 0.65
	environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	environment.fog_enabled = true
	environment.fog_light_color = Color(0.43, 0.39, 0.32) # غبار و دود دوردست
	environment.fog_density = 0.009
	environment.glow_enabled = false

	var world_environment := WorldEnvironment.new()
	world_environment.name = "ArenaWorldEnvironment"
	world_environment.environment = environment
	add_child(world_environment)

	sun = DirectionalLight3D.new()
	sun.name = "ArenaSun"
	sun.rotation_degrees = Vector3(-32.0, -28.0, 0.0)
	sun.light_energy = 1.05
	sun.light_color = Color(0.82, 0.75, 0.62)
	sun.shadow_enabled = true
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
	sun.directional_shadow_max_distance = 65.0
	add_child(sun)


# -------------------------------------------------------------------
# Shared geometry helpers
# -------------------------------------------------------------------

func _add_static_box(
	pos: Vector3,
	size: Vector3,
	color: Color,
	yaw: float = 0.0,
	register_on_map: bool = true
) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.position = pos
	body.rotation.y = yaw
	body.collision_layer = 1
	body.collision_mask = 0

	var mesh_instance := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh_instance.mesh = mesh
	mesh_instance.material_override = _mat(color)

	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	collision.shape = shape

	body.add_child(mesh_instance)
	body.add_child(collision)
	add_child(body)

	if register_on_map:
		_register_rect(pos, size, yaw)

	return body


func _register_rect(pos: Vector3, size: Vector3, yaw: float = 0.0) -> void:
	# Calculate the true axis-aligned bounds of a rotated rectangle.
	var half_x := size.x * 0.5
	var half_z := size.z * 0.5
	var c := absf(cos(yaw))
	var s := absf(sin(yaw))
	var extent_x := c * half_x + s * half_z
	var extent_z := s * half_x + c * half_z
	
	map_rects.append(
		Rect2(
			Vector2(pos.x - extent_x, pos.z - extent_z),
			Vector2(extent_x * 2.0, extent_z * 2.0)
		)
	)


# Retain the original helper name and argument order for other scripts.
func add_box(pos: Vector3, size: Vector3, color: Color, yaw: float = 0.0, on_map: bool = true) -> void:
	_add_static_box(pos, size, color, yaw, on_map)


func _stripe(pos: Vector3, size: Vector3, color: Color, yaw: float) -> void:
	var mesh_instance := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh_instance.mesh = mesh
	mesh_instance.material_override = _mat(color)
	mesh_instance.position = pos
	mesh_instance.rotation.y = yaw
	mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mesh_instance)


# -------------------------------------------------------------------
# Ground
# -------------------------------------------------------------------

func _build_ground() -> void:
	var image := Image.create(2, 2, false, Image.FORMAT_RGB8)
	image.set_pixel(0, 0, ARENA_COLOR)
	image.set_pixel(1, 1, ARENA_COLOR)
	image.set_pixel(1, 0, ARENA_DARK)
	image.set_pixel(0, 1, ARENA_DARK)

	var texture := ImageTexture.create_from_image(image)
	var ground_material := StandardMaterial3D.new()
	ground_material.albedo_texture = texture
	ground_material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	ground_material.uv1_scale = Vector3(20.0, 20.0, 1.0)
	ground_material.roughness = 1.0

	var body := StaticBody3D.new()
	body.name = "ArenaGround"
	body.position = Vector3(0, -0.5, 0)
	body.collision_layer = 1
	body.collision_mask = 0

	var mesh_instance := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = Vector3(HALF * 2.0, 1.0, HALF * 2.0)
	mesh_instance.mesh = mesh
	mesh_instance.material_override = ground_material

	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = mesh.size
	collision.shape = shape

	body.add_child(mesh_instance)
	body.add_child(collision)
	add_child(body)


# -------------------------------------------------------------------
# Decorative geometry and gameplay props
# -------------------------------------------------------------------

func _rock(x: float, z: float, radius: float, height: float) -> void:
	var body := StaticBody3D.new()
	body.position = Vector3(x, height * 0.5, z)
	body.rotation.y = randf() * TAU
	body.collision_layer = 1
	body.collision_mask = 0

	var mesh := CylinderMesh.new()
	mesh.top_radius = radius * 0.6
	mesh.bottom_radius = radius
	mesh.height = height
	mesh.radial_segments = 6
	mesh.rings = 1

	var mesh_instance := MeshInstance3D.new()
	mesh_instance.mesh = mesh
	mesh_instance.material_override = _mat(Color(0.25, 0.25, 0.30))

	var collision := CollisionShape3D.new()
	var shape := CylinderShape3D.new()
	shape.radius = radius * 0.85
	shape.height = height
	collision.shape = shape

	body.add_child(mesh_instance)
	body.add_child(collision)
	add_child(body)

	map_rects.append(
		Rect2(
			Vector2(x - radius, z - radius),
			Vector2(radius * 2.0, radius * 2.0)
		)
	)


func _barrier(x: float, z: float, yaw: float) -> void:
	add_box(
		Vector3(x, 0.65, z),
		Vector3(4.0, 1.3, 0.8),
		Color(0.31, 0.30, 0.27),
		yaw
	)
	_stripe(
		Vector3(x, 1.31, z),
		Vector3(4.02, 0.04, 0.82),
		Color(0.62, 0.48, 0.22),
		yaw
	)


# Neon is decorative only: it deliberately has no collision shape and
# does not pollute map_rects or the AI obstacle list.
func add_neon_box(pos: Vector3, size: Vector3, color: Color, yaw: float = 0.0) -> void:
	var mesh_instance := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh_instance.mesh = mesh
	mesh_instance.material_override = _emissive_mat(color, 3.0)
	mesh_instance.position = pos
	mesh_instance.rotation.y = yaw
	mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mesh_instance)


# Ramp is a static collision surface. Rotation is around Z so its slope
# runs along the X axis, matching the two side-platform entrances below.
func add_ramp(pos: Vector3, size: Vector3, color: Color, rot_x_degrees: float) -> void:
	var body := StaticBody3D.new()
	body.position = pos
	body.rotation.z = deg_to_rad(rot_x_degrees)
	body.collision_layer = 1
	body.collision_mask = 0

	var mesh_instance := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh_instance.mesh = mesh
	mesh_instance.material_override = _mat(color)

	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	collision.shape = shape

	body.add_child(mesh_instance)
	body.add_child(collision)
	add_child(body)


# -------------------------------------------------------------------
# Arena boundary
# -------------------------------------------------------------------

func _build_walls() -> void:
	add_box(
		Vector3(0, 3, -HALF - 0.5),
		Vector3(HALF * 2.0 + 2.0, 6, 1),
		WALL_COLOR, 0.0, false
	)
	add_box(
		Vector3(0, 3, HALF + 0.5),
		Vector3(HALF * 2.0 + 2.0, 6, 1),
		WALL_COLOR, 0.0, false
	)
	add_box(
		Vector3(HALF + 0.5, 3, 0),
		Vector3(1, 6, HALF * 2.0 + 2.0),
		WALL_COLOR, 0.0, false
	)
	add_box(
		Vector3(-HALF - 0.5, 3, 0),
		Vector3(1, 6, HALF * 2.0 + 2.0),
		WALL_COLOR, 0.0, false
	)

	var trim_color := Color(0.43, 0.31, 0.22) # رنگ زنگ‌زده و فرسوده
	_stripe(Vector3(0, 1.5, -HALF + 0.1), Vector3(HALF * 2.0, 0.12, 0.10), trim_color, 0.0)
	_stripe(Vector3(0, 1.5, HALF - 0.1), Vector3(HALF * 2.0, 0.12, 0.10), trim_color, 0.0)
	_stripe(Vector3(HALF - 0.1, 1.5, 0), Vector3(0.10, 0.12, HALF * 2.0), trim_color, 0.0)
	_stripe(Vector3(-HALF + 0.1, 1.5, 0), Vector3(0.10, 0.12, HALF * 2.0), trim_color, 0.0)


# -------------------------------------------------------------------
# Cover, platforms and arena layout
# -------------------------------------------------------------------

func _build_cover() -> void:
	var concrete := Color(0.29, 0.28, 0.24)
	var platform_color := Color(0.27, 0.29, 0.26)
	var ramp_color := Color(0.37, 0.35, 0.29)

	# Central four-sided shelter. The roof remains a visual feature,
	# while the side walls retain their normal collision.
	add_box(Vector3(-3.5, 1.5, -4), Vector3(3, 3, 0.6), concrete)
	add_box(Vector3(3.5, 1.5, -4), Vector3(3, 3, 0.6), concrete)
	add_box(Vector3(-3.5, 1.5, 4), Vector3(3, 3, 0.6), concrete)
	add_box(Vector3(3.5, 1.5, 4), Vector3(3, 3, 0.6), concrete)
	add_box(Vector3(-5, 1.5, 0), Vector3(0.6, 3, 8.6), concrete)
	add_box(Vector3(5, 1.5, 0), Vector3(0.6, 3, 8.6), concrete)
	add_box(Vector3(0, 0.6, 0), Vector3(1.5, 1.2, 1.5), Color(0.65, 0.45, 0.24))
	add_box(Vector3(0, 3.1, 0), Vector3(10.6, 0.16, 8.6), Color(0.22, 0.19, 0.16), 0.0, false)

	# Raised north-west platform. The ramp rises from east to west.
	add_box(Vector3(-20, 1.5, -20), Vector3(12, 3, 12), platform_color)
	add_ramp(Vector3(-10, 1.5, -20), Vector3(8.0, 0.45, 5.0), ramp_color, -22.0)
	add_box(Vector3(-26, 3.08, -20), Vector3(0.14, 0.12, 11.5), Color(0.39, 0.29, 0.20), 0.0, false)

	# Raised south-east platform. The ramp rises from west to east.
	add_box(Vector3(20, 1.5, 20), Vector3(12, 3, 12), platform_color)
	add_ramp(Vector3(10, 1.5, 20), Vector3(8.0, 0.45, 5.0), ramp_color, 22.0)
	add_box(Vector3(26, 3.08, 20), Vector3(0.14, 0.12, 11.5), Color(0.39, 0.29, 0.20), 0.0, false)

	# Concrete barriers.
	_barrier(-12, -8, 0.0)
	_barrier(12, 8, 0.0)
	_barrier(-15, 10, PI * 0.5)
	_barrier(15, -10, PI * 0.5)
	_barrier(0, -16, 0.0)
	_barrier(0, 16, 0.0)

	# Shipping containers.
	add_box(Vector3(-16, 1.3, 8), Vector3(2.4, 2.6, 6), Color(0.27, 0.31, 0.29))
	add_box(Vector3(16, 1.3, -8), Vector3(2.4, 2.6, 6), Color(0.43, 0.27, 0.20))

	# Structural columns.
	for point in [
		Vector3(-9, 1.75, -9),
		Vector3(9, 1.75, 9),
		Vector3(-9, 1.75, 9),
		Vector3(9, 1.75, -9),
	]:
		add_box(point, Vector3(1.2, 3.5, 1.2), Color(0.34, 0.33, 0.29))

	# --- جزئیات ژاپنی و آخرالزمانی: دروازه فرسوده، تیرهای شکسته و آوار ---
	# دروازه الهام‌گرفته از توریی؛ صرفاً تزئینی و بدون برخورد
	var torii_red := Color(0.43, 0.19, 0.15)
	_stripe(Vector3(0, 2.5, -23), Vector3(7.0, 0.42, 0.42), torii_red, 0.0)
	_stripe(Vector3(0, 2.15, -23), Vector3(5.8, 0.18, 0.28), Color(0.30, 0.20, 0.16), 0.0)
	_stripe(Vector3(-2.6, 1.15, -23), Vector3(0.38, 2.3, 0.38), torii_red, 0.0)
	_stripe(Vector3(2.6, 1.15, -23), Vector3(0.38, 2.3, 0.38), torii_red, 0.0)

	# تکه‌سنگ و بتن خردشده در حاشیه مسیرها
	add_box(Vector3(-22, 0.28, 2), Vector3(2.8, 0.55, 1.6), Color(0.31, 0.30, 0.26), 0.28)
	add_box(Vector3(22, 0.22, -2), Vector3(2.2, 0.42, 1.2), Color(0.28, 0.28, 0.25), -0.35)
	add_box(Vector3(-3, 0.18, 23), Vector3(3.0, 0.35, 1.0), Color(0.32, 0.29, 0.23), 0.5)
	add_box(Vector3(4, 0.16, -23), Vector3(2.4, 0.30, 1.1), Color(0.29, 0.28, 0.24), -0.4)

	# تیرهای چوبی فرسوده کنار خرابه‌ها
	add_box(Vector3(-24, 1.1, 18), Vector3(0.22, 2.2, 0.22), Color(0.25, 0.18, 0.13), 0.18)
	add_box(Vector3(-23.5, 0.65, 18), Vector3(2.0, 0.18, 0.18), Color(0.29, 0.21, 0.15), -0.25)
	add_box(Vector3(24, 0.9, -18), Vector3(0.20, 1.8, 0.20), Color(0.25, 0.18, 0.13), -0.2)

	# تابلوهای کهنه و مات؛ بدون نوشته وابسته به فونت یا تکسچر خارجی
	add_box(Vector3(-7, 2.0, -5.0), Vector3(1.4, 0.9, 0.12), Color(0.38, 0.29, 0.20), 0.0, false)
	add_box(Vector3(7, 2.0, 5.0), Vector3(1.4, 0.9, 0.12), Color(0.38, 0.29, 0.20), PI, false)

	# Rocks. Randomness is visual only; gameplay spawn points stay fixed.
	var rock_positions: Array[Vector2] = [
		Vector2(-18, -14), Vector2(18, 14),
		Vector2(-18, 16), Vector2(18, -16),
		Vector2(-8, 20), Vector2(8, -20),
		Vector2(-24, -4), Vector2(24, 4),
		Vector2(-6, -12), Vector2(6, 12),
	]
	for point in rock_positions:
		_rock(
			point.x,
			point.y,
			randf_range(1.3, 1.9),
			randf_range(2.0, 3.2)
		)
